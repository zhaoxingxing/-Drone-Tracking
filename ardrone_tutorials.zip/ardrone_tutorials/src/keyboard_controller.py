#!/usr/bin/env python

# The Keyboard Controller Node for the tutorial "Up and flying with the AR.Drone and ROS | Getting Started"
# https://github.com/mikehamer/ardrone_tutorials

# This controller extends the base DroneVideoDisplay class, adding a keypress handler to enable keyboard control of the drone

# Import the ROS libraries, and load the manifest file which through <depend package=... /> will give us access to the project dependencies
import roslib; roslib.load_manifest('ardrone_tutorials')
import rospy

# Load the DroneController class, which handles interactions with the drone, and the DroneVideoDisplay class, which handles video display
from drone_controller import BasicDroneController
from drone_video_display import DroneVideoDisplay

# Finally the GUI libraries
from PySide import QtCore, QtGui

# Load library of OpenCV
import cv2

# Load library of numpy
import numpy as np

# Utilisateur interface mode manuel
img = np.zeros((768,512,3), np.uint8)

font = cv2.FONT_HERSHEY_PLAIN
cv2.putText(img, 'MODE MANUEL', (125, 30), font, 2, (200, 255,255),0, False)
cv2.putText(img, 'ESPACE---------------Urgent', (100, 100), font, 1, (25, 55,255),0, False)
cv2.putText(img, 'Y--------------------Decoller', (100, 150), font, 1, (88, 255,255),0, False)
cv2.putText(img, 'H--------------------Aterrir', (100, 200), font, 1, (88, 255,255),0, False)
cv2.putText(img, 'E--------------------Avancer', (100, 250), font, 1, (255, 255,255),0,False)
cv2.putText(img, 'D--------------------Reculer', (100, 300), font, 1, (255, 255,255),0,False)
cv2.putText(img, 'Q--------------------Monter', (100, 350), font, 1, (200, 200,255),0,False)
cv2.putText(img, 'A--------------------Descendre', (100, 400), font, 1, (200, 200,255),0,False)
cv2.putText(img, 'R--------------------Tourner Droit', (100, 450), font, 1, (125, 150,255),0,False)
cv2.putText(img, 'Z--------------------Tourner Gauche', (100, 500), font, 1, (125, 150,255),0,False)
cv2.putText(img, 'F--------------------Decaler Droit', (100, 550), font, 1, (75, 155,255),0,False)
cv2.putText(img, 'S--------------------Decaler Gauche', (100, 600), font, 1, (75, 155,255),0,False)
cv2.putText(img, 'M--------------------Changer Mode', (100, 700), font, 1, (125, 55,255),0,False)
cv2.imshow('KeyboardMap', img)


# Utilisateur interface mode autonome
img1 = np.zeros((515,512,3), np.uint8)
font1 = cv2.FONT_HERSHEY_PLAIN
cv2.putText(img1, 'MODE AUTONOME', (125, 30), font1, 2, (200, 255,255),0, False)
cv2.putText(img1, 'ESPACE---------------Urgent', (100, 100), font1, 1, (25, 55,255),0, False)
cv2.putText(img1, 'Y--------------------Decoller', (100, 150), font1, 1, (88, 255,255),0, False)
cv2.putText(img1, 'H--------------------Aterrir', (100, 200), font1, 1, (88, 255,255),0, False)
cv2.putText(img1, 'M--------------------Changer Mode', (100, 250), font1, 1, (125, 55,255),0,False)
cv2.putText(img1, 'Attention A La Cible', (100, 350), font1, 2, (125, 55,255),0,False)


# Here we define the keyboard map for our controller (note that python has no enums, so we use a class)
class KeyMapping(object):
	PitchForward     = QtCore.Qt.Key.Key_E
	PitchBackward    = QtCore.Qt.Key.Key_D
	RollLeft         = QtCore.Qt.Key.Key_S
	RollRight        = QtCore.Qt.Key.Key_F
	YawLeft          = QtCore.Qt.Key.Key_Z
	YawRight         = QtCore.Qt.Key.Key_R
	IncreaseAltitude = QtCore.Qt.Key.Key_Q
	DecreaseAltitude = QtCore.Qt.Key.Key_A
	Takeoff          = QtCore.Qt.Key.Key_Y
	Land             = QtCore.Qt.Key.Key_H
	Emergency        = QtCore.Qt.Key.Key_Space
	Homolo           = QtCore.Qt.Key.Key_T
	ChangeMode       = QtCore.Qt.Key.Key_M

# Our controller definition, note that we extend the DroneVideoDisplay class
class KeyboardController(DroneVideoDisplay):
	def __init__(self):
		super(KeyboardController,self).__init__()
		self.pitch = 0
		self.roll = 0
		self.yaw_velocity = 0 
		self.z_velocity = 0
		self.test = 0
		self.modechange == "Manuel"

# We add a keyboard handler to the DroneVideoDisplay to react to keypresses
	def keyPressEvent(self, event):
		key = event.key()
		self.pitch = 0
		self.roll = 0
		self.yaw_velocity = 0 
		self.z_velocity = 0

		# If we have constructed the drone controller and the key is not generated from an auto-repeating key
		if controller is not None and not event.isAutoRepeat():
			# Handle the important cases first!
			if key == KeyMapping.Emergency:
				controller.SendEmergency()
				self.deplacement = "Urgent"
			elif key == KeyMapping.Takeoff:
				controller.SendTakeoff()
				self.deplacement = "Decoller"
			elif key == KeyMapping.Land:
				controller.SendLand()
				self.deplacement = "Aterrir"
			else:
				# Now we handle moving, notice that this section is the opposite (+=) of the keyrelease section
				if key == KeyMapping.YawLeft and self.modechange == "Manuel":
					self.yaw_velocity = 1					
					self.deplacement = "Tourner Gauche"
				elif key == KeyMapping.YawRight and self.modechange == "Manuel":
					self.yaw_velocity = -1
					self.deplacement = "Tourner Droit"

				elif key == KeyMapping.PitchForward and self.modechange == "Manuel":
					self.pitch = 1
					self.deplacement = "Avancer"
				elif key == KeyMapping.PitchBackward and self.modechange == "Manuel":
					self.pitch = -1
					self.deplacement = "Reculer"

				elif key == KeyMapping.RollLeft and self.modechange == "Manuel":
					self.roll = 1
					self.deplacement = "Decaler Gauche"
				elif key == KeyMapping.RollRight and self.modechange == "Manuel":
					self.roll = -1
					self.deplacement = "Decaler Droit"

				elif key == KeyMapping.IncreaseAltitude and self.modechange == "Manuel":
					self.z_velocity = 1
					self.deplacement = "Monter"
				elif key == KeyMapping.DecreaseAltitude and self.modechange == "Manuel":
					self.z_velocity = -1
				# Plus a bouthon M to change the mode 
				elif key == KeyMapping.ChangeMode:
					if self.modechange == "Manuel":
						self.modechange = "Autonome"
						self.deplacement = "Fait Attention La Distance"
						cv2.destroyWindow('KeyboardMap')
						cv2.imshow('AUTONOME', img1)
					else:
						self.modechange = "Manuel"
						self.deplacement = "Utilise Le Clavier"
						cv2.imshow('KeyboardMap', img)
						cv2.destroyWindow('AUTONOME')
			# finally we set the command to be sent. The controller handles sending this at regular intervals
			controller.SetCommand(self.roll, self.pitch, self.yaw_velocity, self.z_velocity,self.modechange)

	def keyReleaseEvent(self,event):
		key = event.key()

		# If we have constructed the drone controller and the key is not generated from an auto-repeating key
		if controller is not None and not event.isAutoRepeat() and self.modechange == "Manuel":
			# Note that we don't handle the release of emergency/takeoff/landing keys here, there is no need.
			# Now we handle moving, notice that this section is equal 0 after release of the keypress section
			self.deplacement = "Utilise Le Clavier"
			if key == KeyMapping.YawLeft:
				self.yaw_velocity = 0
			elif key == KeyMapping.YawRight:
				self.yaw_velocity = 0

			elif key == KeyMapping.PitchForward:
				self.pitch = 0
			elif key == KeyMapping.PitchBackward:
				self.pitch = 0

			elif key == KeyMapping.RollLeft:
				self.roll = 0
			elif key == KeyMapping.RollRight:
				self.roll = 0

			elif key == KeyMapping.IncreaseAltitude:
				self.z_velocity = 0
			elif key == KeyMapping.DecreaseAltitude:
				self.z_velocity = 0
			# finally we set the command to be sent. The controller handles sending this at regular intervals
			controller.SetCommand(self.roll, self.pitch, self.yaw_velocity, self.z_velocity)

# Setup the application
if __name__=='__main__':
	import sys
	# Firstly we setup a ros node, so that we can communicate with the other packages
	rospy.init_node('ardrone_keyboard_controller')

	# Now we construct our Qt Application and associated controllers and windows
	app = QtGui.QApplication(sys.argv)
	controller = BasicDroneController()
	display = KeyboardController()
	display.show()

	# executes the QT application
	status = app.exec_()

	# and only progresses to here once the application has been shutdown
	rospy.signal_shutdown('Great Flying!')
	sys.exit(status)
