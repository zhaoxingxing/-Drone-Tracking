#!/usr/bin/env python

# A basic drone controller class for the tutorial "Up and flying with the AR.Drone and ROS | Getting Started"
# https://github.com/mikehamer/ardrone_tutorials_getting_started

# This class implements basic control functionality which we will be using in future tutorials.
# It can command takeoff/landing/emergency as well as drone movement
# It also tracks the drone state based on navdata feedback

# Import the ROS libraries, and load the manifest file which through <depend package=... /> will give us access to the project dependencies
import roslib; roslib.load_manifest('ardrone_tutorials')
import rospy

# Import the messages we're interested in sending and receiving
from geometry_msgs.msg import Twist  	 # for sending commands to the drone
from std_msgs.msg import Empty       	 # for land/takeoff/emergency
from ardrone_autonomy.msg import Navdata # for receiving navdata feedback

# An enumeration of Drone Statuses
from drone_status import DroneStatus

from drone_video_display import DroneVideoDisplay

# The three parameters of reference image en pourcentage
x1 = 58
y1 = 55
t1 = 42

# The three parameters of current image
x2=2
y2=5
t2=5


# The parameter of turn left and turn right en pourcentage
x1min = 46
x1max = 70


# The parameter of go up and go down en pourcentage
y1min = 45
y1max = 65

# The parameter of foward and backward en pourcentage
t1min = 31
t1max = 56

# A variable as the register to conrtol priority
mode = 0

# Some Constants
COMMAND_PERIOD = 80 #ms

class BasicDroneController(object):
	def __init__(self):
		global x2,y2,t2
		# Holds the current drone status
		self.status = -1
		# Subscribe to the /ardrone/navdata topic, of message type navdata, and call self.ReceiveNavdata when a message is received
		self.subNavdata = rospy.Subscriber('/ardrone/navdata',Navdata,self.ReceiveNavdata) 
		# Allow the controller to publish to the /ardrone/takeoff, land and reset topics
		self.pubLand    = rospy.Publisher('/ardrone/land',Empty,queue_size=10)
		self.pubTakeoff = rospy.Publisher('/ardrone/takeoff',Empty,queue_size=10)
		self.pubReset   = rospy.Publisher('/ardrone/reset',Empty,queue_size=10)
		self.pubHomolo  = rospy.Publisher('/ardrone/homolo',Empty,queue_size=10)
		# Allow the controller to publish to the /cmd_vel topic and thus control the drone
		self.pubCommand = rospy.Publisher('/cmd_vel',Twist,queue_size=10)

		# Setup regular publishing of control packets
		self.command = Twist()
		self.commandTimer = rospy.Timer(rospy.Duration(COMMAND_PERIOD/1000.0),self.SendCommand)
		self.change = "manuel"

		# Land the drone if we are shutting down
		rospy.on_shutdown(self.SendLand)
	def ReceiveNavdata(self,navdata):
		# Although there is a lot of data in this packet, we're only interested in the state at the moment	
		self.status = navdata.state

	def SendTakeoff(self):
		# Send a takeoff message to the ardrone driver
		# Note we only send a takeoff message if the drone is landed - an unexpected takeoff is not good!
		if(self.status == DroneStatus.Landed):
			self.pubTakeoff.publish(Empty())

	def SendLand(self):
		# Send a landing message to the ardrone driver
		# Note we send this in all states, landing can do no harm
		self.pubLand.publish(Empty())

	def SendEmergency(self):
		# Send an emergency (or reset) message to the ardrone driver
		self.pubReset.publish(Empty())

	def SendHomolo(self):
		#send a homolo message to the ardrone driver
		self.pubHomolo.publish(Empty())

	def SetCommand(self, roll=0, pitch=0, yaw_velocity=0, z_velocity=0, modechange = "Manuel"):
		global x2,y2,t2
		# Called by the main program to set the current command and mode to change 
		self.command.linear.x  = pitch
		self.command.linear.y  = roll
		self.command.linear.z  = z_velocity
		self.command.angular.z = yaw_velocity
		self.change = modechange

	def SendCommand(self,event):
		# With the  key word "global", we can use the global variables 
		global x1,y1,t1,x1max,x1min,y1max,y1min,t1max,t1min,mode,x2,y2,t2
		# The previously set command is then sent out periodically if the drone is flying
		
		if (self.status == DroneStatus.Flying or self.status == DroneStatus.GotoHover or self.status == DroneStatus.Hovering or self.status == DroneStatus.Homolo):
			if self.change == "Autonome":
				# Three parameters controled by the trackbar to simulate the results of image processing
				#x2=cv2.getTrackbarPos('ax_x','trois_variable')
				#y2=cv2.getTrackbarPos('ax_y','trois_variable')
				#t2=cv2.getTrackbarPos('ax_t','trois_variable')
				self.command.angular.z = 0
				self.command.linear.z = 0
				self.command.linear.x = 0


				# Get the parameters from the image processing
				x2 = rospy.get_param("/CoordX2")
				y2 = rospy.get_param("/CoordY2")
				t2 = rospy.get_param("/CoordT2")
				"""
				if (y2 <= y1min or y2 >= y1max):
					if y2 > y1 :
						self.command.linear.z = -1
					else:
						self.command.linear.z = 1 
				else:
					self.command.angular.z = 0
					self.command.linear.z = 0
					self.command.linear.x = 0

				"""
				"""
				if x2 <= x1min or x2 >= x1max :
					if x2 > x1 :
						self.command.angular.z = -1
					else:
						self.command.angular.z = 1
				if (t2 <= t1min or t2 >= t1max) :
					if t2 > t1 :
						self.command.linear.x = -1
					else:
						self.command.linear.x = 1
				if (y2 <= y1min or y2 >= y1max):
					if y2 > y1 :
						self.command.linear.z = -1
					else:
						self.command.linear.z = 1
				else:
					self.command.angular.z = 0
					self.command.linear.z = 0
					self.command.linear.x = 0
				"""

				# When the drone is in the left of the screen we command it to roll right and when the drone is in the right of the screen we command it to roll left
				if x2 <= x1min or x2 >= x1max :
					if mode == 2:
						self.command.linear.x = 0
						self.command.linear.z = 0
						self.command.angular.z = 0
					if mode == 3:
						self.command.linear.x = 0
						self.command.linear.z = 0
						self.command.angular.z = 0
					mode = 1
					if x2 > x1 :
						self.command.angular.z = -1
					else:
						self.command.angular.z = 1
				# When the drone is close to the object we command it to go back and when the drone is far away from the objet we command it to go forward	
				elif (t2 <= t1min or t2 >= t1max) and mode != 1 :
					if mode == 3:
						self.command.linear.x = 0
						self.command.linear.z = 0
						self.command.angular.z = 0
					mode = 2
					if t2 > t1 :
						self.command.linear.x = -1
					else:
						self.command.linear.x = 1
				# When the drone is blow the object we command it to go up and when the drone is over the objet we command it to go down
				elif (y2 <= y1min or y2 >= y1max) and mode != 2 and mode != 1 :
					mode = 3
					if y2 > y1 :
						self.command.linear.z = -1
					else:
						self.command.linear.z = 1
				# When the drone losts the target or the target satisfies three parameters, the drone hovors
				else:
					mode = 0
					self.command.angular.z = 0
					self.command.linear.z = 0
					self.command.linear.x = 0
			# Send the command to the drone after image processing
			self.pubCommand.publish(self.command)



