#!/usr/bin/env python

# A basic video display window for the tutorial "Up and flying with the AR.Drone and ROS | Getting Started"
# https://github.com/mikehamer/ardrone_tutorials_getting_started

# This display window listens to the drone's video feeds and updates the display at regular intervals
# It also tracks the drone's status and any connection problems, displaying them in the window's status bar
# By default it includes no control functionality. The class can be extended to implement key or mouse listeners if required

# Import the ROS libraries, and load the manifest file which through <depend package=... /> will give us access to the project dependencies
import roslib; roslib.load_manifest('ardrone_tutorials')
import rospy
import cv2
import numpy as np

from cv_bridge import CvBridge, CvBridgeError


# Import the two types of messages we're interested in
from sensor_msgs.msg import Image    	 # for receiving the video feed
from ardrone_autonomy.msg import Navdata # for receiving navdata feedback

# We need to use resource locking to handle synchronization between GUI thread and ROS topic callbacks
from threading import Lock

# An enumeration of Drone Statuses
from drone_status import DroneStatus

# The GUI libraries
from PySide import QtCore, QtGui

#from drone_controller import OpencvSimulation

# Some Constants
CONNECTION_CHECK_PERIOD = 300 #ms
GUI_UPDATE_PERIOD = 70 #ms
DETECT_RADIUS = 4 # the radius of the circle drawn when a tag is detected
kernel = np.ones((5,5),np.uint8)

CoordX2 = 5
CoordY2 = 5
CoordT2 = 5

X2 = 0
Y2 = 0
T2 = 0

hmin = 0
hmax = 255
smin = 0
smax = 255
vmin = 0
vmax = 255

def nothing(x):
	pass

class DroneVideoDisplay(QtGui.QMainWindow):
	StatusMessages = {
		DroneStatus.Emergency    : 'Emergency',
		DroneStatus.Inited       : 'Initialized',
		DroneStatus.Landed       : 'Landed',
		DroneStatus.Flying       : 'Flying',
		DroneStatus.Hovering     : 'Hovering',
		DroneStatus.TakingOff    : 'Taking Off',
		DroneStatus.Homolo       : 'Homologation',
		DroneStatus.Test         : 'Test (?)',
		DroneStatus.ModeAutonome : 'autonome',
		DroneStatus.ModeManuel   : 'manuel',
		DroneStatus.GotoHover    : 'Going to Hover Mode',
		DroneStatus.Landing      : 'Landing',
		DroneStatus.Looping      : 'Looping (?)'
		}

	DisconnectedMessage = 'Disconnected'
	UnknownMessage = 'Unknown Status'
	def __init__(self):
		# Construct the parent class
		super(DroneVideoDisplay, self).__init__()

		# Setup our very basic GUI - a label which fills the whole window and holds our image
		self.setWindowTitle('AR.Drone Video Feed')
		self.imageBox = QtGui.QLabel(self)
		self.setCentralWidget(self.imageBox)

		self.bridge = CvBridge()

		# Subscribe to the /ardrone/navdata topic, of message type navdata, and call self.ReceiveNavdata when a message is received
		self.subNavdata = rospy.Subscriber('/ardrone/navdata',Navdata,self.ReceiveNavdata) 
		
		# Subscribe to the drone's video feed, calling self.ReceiveImage when a new frame is received
		self.subVideo   = rospy.Subscriber('/ardrone/image_raw',Image,self.ReceiveImage)
		
		# Holds the image frame received from the drone and later processed by the GUI
		self.image = None
		self.imageLock = Lock()

		self.tags = []
		self.tagLock = Lock()
		
		# Holds the status message to be displayed on the next GUI update
		self.statusMessage = ''

		# Tracks whether we have received data since the last connection check
		# This works because data comes in at 50Hz but we're checking for a connection at 4Hz
		self.communicationSinceTimer = False
		self.connected = False

		# A timer to check whether we're still connected
		self.connectionTimer = QtCore.QTimer(self)
		self.connectionTimer.timeout.connect(self.ConnectionCallback)
		self.connectionTimer.start(CONNECTION_CHECK_PERIOD)
		
		# A timer to redraw the GUI
		self.redrawTimer = QtCore.QTimer(self)
		self.redrawTimer.timeout.connect(self.RedrawCallback)
		self.redrawTimer.start(GUI_UPDATE_PERIOD)

		# initialization that we want display blow the video window
		self.modechange = "Manuel"
		self.deplacement = "wait Command"
		self.x2 = 5
		self.y2 = 5
		self.t2 = 5

		"""
		# Create these trackbars
		cv2.namedWindow('image')
		cv2.createTrackbar('Hmin','image',0,255,nothing)
		cv2.createTrackbar('Hmax','image',255,255,nothing)
		cv2.createTrackbar('Smin','image',0,255,nothing)
		cv2.createTrackbar('Smax','image',255,255,nothing)
		cv2.createTrackbar('Vmin','image',0,255,nothing)
		cv2.createTrackbar('Vmax','image',255,255,nothing)
		"""
	# Called every CONNECTION_CHECK_PERIOD ms, if we haven't received anything since the last callback, will assume we are having network troubles and display a message in the status bar
	def ConnectionCallback(self):
		self.connected = self.communicationSinceTimer
		self.communicationSinceTimer = False
	def RedrawCallback(self):
		global CoordX2,CoordY2,CoordT2,X2,Y2,T2,hmax,hmin,vmax,vmin,smax,smin
		if self.image is not None:
			# We have some issues with locking between the display thread and the ros messaging thread due to the size of the image, so we need to lock the resources
			self.imageLock.acquire()
			try:			
				# Convert the ROS image into a QImage which we can display
				image = QtGui.QPixmap.fromImage(QtGui.QImage(self.image.data, self.image.width, self.image.height, QtGui.QImage.Format_RGB888))
				if len(self.tags) > 0:
					self.tagLock.acquire()
					try:
						painter = QtGui.QPainter()
						painter.begin(image)
						painter.setPen(QtGui.QColor(0,255,0))
						painter.setBrush(QtGui.QColor(0,255,0))
						for (x,y,d) in self.tags:
							r = QtCore.QRectF((x*image.width())/1000-DETECT_RADIUS,(y*image.height())/1000-DETECT_RADIUS,DETECT_RADIUS*2,DETECT_RADIUS*2)
							painter.drawEllipse(r)
							painter.drawText((x*image.width())/1000+DETECT_RADIUS,(y*image.height())/1000-DETECT_RADIUS,str(d/100)[0:4]+'m')
						painter.end()
					finally:
						self.tagLock.release()
			finally:
				self.imageLock.release()

			# We could  do more processing (eg OpenCV) here if we wanted to, but for now lets just display the window.
			self.resize(image.width(),image.height())
			self.imageBox.setPixmap(image)


			try:
				frame = self.bridge.imgmsg_to_cv2(self.image, "bgr8")

				
				# Convert BGR to HSV
				hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
				"""
				# Use the trackbar to adjust the color that we want
				hmin = cv2.getTrackbarPos('Hmin','image')
				hmax = cv2.getTrackbarPos('Hmax','image')
				smin = cv2.getTrackbarPos('Smin','image')
				smax = cv2.getTrackbarPos('Smax','image')
				vmin = cv2.getTrackbarPos('Vmin','image')
				vmax = cv2.getTrackbarPos('Vmax','image')
				"""

				"""
				# logo extincteur vert
				hmin = 30
				hmax = 45
				smin = 150
				smax = 235
				vmin = 110
				vmax = 205
				"""

				# gilet rouge
				hmin = 170
				hmax = 175
				smin = 110
				smax = 255
				vmin = 0
				vmax = 255
				
				"""
				#stylo jaune claire
				hmin = 25
				hmax = 50
				smin = 100
				smax = 255
				vmin = 46
				vmax = 100
				"""

				# define range of color in HSV
				lower = np.array([hmin,smin,vmin])
				upper = np.array([hmax,smax,vmax])
				
				# Threshold the HSV image to get the colors we need
				mask = cv2.inRange(hsv, lower, upper)
				    
				# 
				closing = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
				height, width = closing.shape
				i = 0
				j = 0
				imax = 0
				jmax = 0
				imin = width
				jmin = height
				for i in range(0, width/3):
					for j in range(0, height/3):
						pixel = closing[j*3, i*3]
						if pixel:
							if i*3 < imin:
								imin = i*3
							if j*3 < jmin:
								jmin = j*3
							if i*3 > imax:
						    		imax = i*3
							if j*3> jmax:
						    		jmax = j*3
				if imax != 0 and imin != width and jmax != 0 and jmin != height:
					cv2.rectangle(frame, (imin, jmin), (imax, jmax), (0, 255, 0), 1)
					cv2.rectangle(frame, (imax + (imin-imax)/2, jmax + (jmin-jmax)/2), (imax + (imin-imax)/2, jmax + (jmin-jmax)/2), (0, 255, 0), 12)
				cv2.imshow('frame',frame)
				"""
				cv2.imshow('mask',mask)
				res = cv2.bitwise_and(frame,frame, mask= mask)
				cv2.imshow('res',res)
				"""
				X2 = imax + (imin-imax)/2
				Y2 = jmax + (jmin-jmax)/2
				T2 =(((imax-imin)/float(width)) +((jmax-jmin)/float(height)))/2
				if T2 == -1 :
					T2 = 0.42

				# set the parameters to share the variables with Loi de command
				rospy.set_param('CoordX2', X2*100/620)
				rospy.set_param('CoordY2', Y2*100/350)
				rospy.set_param('CoordT2', T2*100)
			except CvBridgeError as e:
				print(e)

		# Update the status bar to show the current drone status & battery level
		self.statusBar().showMessage(self.statusMessage if self.connected else self.DisconnectedMessage)
	def ReceiveImage(self,data):
		# Indicate that new data has been received (thus we are connected)
		self.communicationSinceTimer = True
		# We have some issues with locking between the GUI update thread and the ROS messaging thread due to the size of the image, so we need to lock the resources
		self.imageLock.acquire()
		try:
			self.image = data # Save the ros image for processing by the display thread
		finally:
			self.imageLock.release()
	def ReceiveNavdata(self,navdata):
		# Indicate that new data has been received (thus we are connected)
		self.communicationSinceTimer = True
		# Update the message to be displayed
		msg = self.StatusMessages[navdata.state] if navdata.state in self.StatusMessages else self.UnknownMessage
		# Display the drone status, the battery percentaga, the three parameters
		self.statusMessage = '{}--(Battery: {}%)--({})--{}) (X{}) (Y{}) (T{})'.format(msg,int(navdata.batteryPercent),self.modechange,self.deplacement,X2*100/620,Y2*100/350,int(T2*100))
		self.tagLock.acquire()
		try:
			if navdata.tags_count > 0:
				self.tags = [(navdata.tags_xc[i],navdata.tags_yc[i],navdata.tags_distance[i]) for i in range(0,navdata.tags_count)]
			else:
				self.tags = []
		finally:
			self.tagLock.release()

if __name__=='__main__':
	import sys
	rospy.init_node('ardrone_video_display')
	app = QtGui.QApplication(sys.argv)
	display = DroneVideoDisplay()
	display.show()

	status = app.exec_()
	rospy.signal_shutdown('Great Flying!')
	sys.exit(status)
