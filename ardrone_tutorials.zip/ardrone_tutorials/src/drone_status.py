#!/usr/bin/env python

# An enumeration of drone statuses for the tutorial "Up and flying with the AR.Drone and ROS | Getting Started"
# https://github.com/mikehamer/ardrone_tutorials_getting_started


# Here we define the status for our drone (note that python has no enums, so we use a class)
class DroneStatus(object):
	Emergency       = 0
	Inited          = 1
	Landed          = 2
	Flying          = 3
	Hovering        = 4
	TakingOff       = 5
	Homolo          = 6
	Test            = 7
	ModeAutonome    = 8
	ModeManuel      = 9
	GotoHover       = 10
	Landing         = 11
	Looping         = 12

